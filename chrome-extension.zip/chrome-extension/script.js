const testButton = document.querySelector(".test-btn")


function test() {
    console.log("Test button click");
}

testButton.addEventListener("click", () => {
    test()
})
